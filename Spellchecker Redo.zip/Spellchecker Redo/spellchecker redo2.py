import multiprocessing
import time

# Define the file paths
file_path = 'test_source.txt'
oxford_dict_file = 'Oxford English Dictionary.txt'
additional_files = ['6k adverbs.txt', '31k verbs.txt', '91k nouns.txt', '28k adjectives.txt']

def get_num_cores():
    return multiprocessing.cpu_count()

def read_file_content(file_path):
    with open(file_path, 'r', encoding="utf-8") as file:
        return file.read()

def read_oxford_dictionary(file_path):
    with open(file_path, 'r', encoding="utf-8") as file:
        return file.read()

oxford_dict_content = read_oxford_dictionary(oxford_dict_file)
oxford_words = set(word.lower() for word in oxford_dict_content.split() if word.isalpha())

def read_additional_files(file_paths):
    additional_words = set()
    for file_path in file_paths:
        with open(file_path, 'r', encoding="utf-8") as file:
            content = file.read()
            words = set(word.lower() for word in content.split() if word.isalpha())
            additional_words.update(words)
    return additional_words

additional_words = read_additional_files(additional_files)
combined_words = oxford_words.union(additional_words)

def extract_named_entities(text):
    # Split text into sentences
    sentences = text.split('.')
    named_entities = set()
    for sentence in sentences:
        # Skip sentences with colons that typically denote titles or subtitles
        if ':' in sentence:
            continue
        words = sentence.strip().split()
        current_entity = []
        for i, word in enumerate(words):
            if word.istitle():
                current_entity.append(word)
            else:
                if len(current_entity) > 1 or (len(current_entity) == 1 and current_entity[0].lower() not in combined_words):
                    named_entities.add(" ".join(current_entity))
                current_entity = []
        if current_entity:
            if len(current_entity) > 1 or (len(current_entity) == 1 and current_entity[0].lower() not in combined_words):
                named_entities.add(" ".join(current_entity))
    return list(named_entities)

def levenshtein_distance(word1, word2):
    if len(word1) > len(word2):
        word1, word2 = word2, word1
    distances = range(len(word1) + 1)
    for index2, char2 in enumerate(word2):
        new_distances = [index2 + 1]
        for index1, char1 in enumerate(word1):
            if char1 == char2:
                new_distances.append(distances[index1])
            else:
                new_distances.append(1 + min((distances[index1], distances[index1 + 1], new_distances[-1])))
        distances = new_distances
    return distances[-1]

def suggest_word(misspelled_word, combined_words, max_distance=2, num_suggestions=3):
    suggestions = [(word, levenshtein_distance(misspelled_word, word)) for word in combined_words if levenshtein_distance(misspelled_word, word) <= max_distance]
    suggestions.sort(key=lambda x: x[1])
    return [word for word, _ in suggestions[:num_suggestions]]

def check_spelling(text, combined_words):
    words = text.split()
    for word in words:
        if word.istitle() and word.lower() not in combined_words:  # Consider only proper nouns not in dictionary
            continue
        if word.lower() not in combined_words and word.isalpha():
            suggestions = suggest_word(word.lower(), combined_words)
            if suggestions:
                print(f"Misspelled word: '{word}', Suggestions: {suggestions}")

def main():
    num_cores = get_num_cores()
    print(f"Number of CPU cores available: {num_cores}")

    text = read_file_content(file_path)
    named_entities = extract_named_entities(text)
    print("Named Entities Found:", named_entities)

    check_spelling(text, combined_words)

if __name__ == "__main__":
    start_time = time.time()
    main()
    end_time = time.time()
    total_time = end_time - start_time
    print(f"Total runtime: {total_time} seconds")
